<body class="container" style="background-color: #E5E5E5;">
    <div class="row">
        <div class="col-8">
            <h1 class="lista_produtos" style="color: #FFAB40; margin-top: 200px;">Lista de Usuário</h1>
        </div>
        <div class="col-4">
            <div class="form-outline barra-pesquisa">
                <input type="search" id="form1" class="form-control" placeholder="Pesquisar código de produto" aria-label="Search" style="background: #CC7200;" />
              </div>
    </div>
    <!--Tabela Produtos-->
    <div>
        <div class="row produtos" style="text-align: center;">
            <div class="col-2">
                <p>Nome</p>
            </div>
            <div class="col-2">
                <p>Função</p>
            </div>
            <div class="col-2">
                <p>Telefone</p>
            </div>
            <div class="col-2">
                <p>Email</p>
            </div>
            <div class="col-2">
                <p></p>
            </div>
            <div class="col-2">
                <p></p>
            </div>
        </div>
        <div class="row produtos" style="text-align: center; background-color: white; color: #FFAB40;">
            <div class="col-2">
                <p>Desenvolvimento de site</p>
            </div>
            <div class="col-2">
                <p>Master</p>
            </div>
            <div class="col-2">
                <p>(31)996909439</p>
            </div>
            <div class="col-2">
                <p>pedro@gmail.com</p>
            </div>
            <div class="col-2">
                <p></p>
            </div>
            <div class="col-2">
                <p><i class="fa-solid fa-square-minus"></i>         <i class="fa-solid fa-pen-to-square"></i></p>
            </div>
        </div>
        <div class="row produtos" style="text-align: center; background-color: white; color: #FFAB40;">
            <div class="col-2">
                <p>1</p>
            </div>
            <div class="col-2">
                <p>Pão de Sal</p>
            </div>
            <div class="col-2">
                <p>R$0,99</p>
            </div>
            <div class="col-2">
                <p>2</p>
            </div>
            <div class="col-2">
                <p></p>
            </div>
            <div class="col-2">
                <p><i class="fa-solid fa-square-minus"></i>         <i class="fa-solid fa-pen-to-square"></i></p>
            </div>
        </div>
        <div class="row produtos" style="text-align: center; background-color: white; color: #FFAB40;">
            <div class="col-2">
                <p>1</p>
            </div>
            <div class="col-2">
                <p>Pão de Sal</p>
            </div>
            <div class="col-2">
                <p>R$0,99</p>
            </div>
            <div class="col-2">
                <p>2</p>
            </div>
            <div class="col-2">
                <p></p>
            </div>
            <div class="col-2">
                <p><i class="fa-solid fa-square-minus"></i>         <i class="fa-solid fa-pen-to-square"></i></p>
            </div>
        </div>
    </div>
    <!--Botão cadastrar produto-->
    <div class="row">
        <div class="col-12 botao">
            <button type="button" class="btn" style="float: right; background-color:#FFAB40;">Cadastrar Usuário</button>
        </div>
    </div>

        <!--Bootstrap-->
        <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.10.2/dist/umd/popper.min.js" integrity="sha384-7+zCNj/IqJ95wo16oMtfsKbZ9ccEh31eOz1HGyDuCQ6wgnyJNSYdrPa03rtR1zdB" crossorigin="anonymous"></script>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.min.js" integrity="sha384-QJHtvGhmr9XOIpI6YVutG+2QOK9T+ZnN4kzFN1RtK3zEFEIsxhlmWl5/YESvpZ13" crossorigin="anonymous"></script>
</body>