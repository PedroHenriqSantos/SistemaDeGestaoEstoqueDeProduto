<body>
    <header>

        <form id="Sistema">

            <div class="logo">
                <img src="fotos/Logo.png" alt="logo">
            </div>
            <div class="texto">
                <h3>Olá Pedro , Bem Vindo!</h3>
            </div>
            <div class="campo">
                <input type=submit value="Cadastrar Produto">
            </div>

            <div class="campo">
                <input type="submit" value="Cadastrar Categoria" />
            </div>
        </form>
    </header>

    <main>
        <div class="cadastro">
            <section>

                <H1>Cadastro de usuario</H1>

            </section>
            <section class="area dos cadastro">

                <div>
                    <section class="nomep">
                        <input type="text" placeholder="nome">
                    </section>
                </div>
                <div>
                    <section class="senha">
                        <input type="password" placeholder="senha">
                    </section>
                    <div>
                        <div>
                            <section class="funçao">
                                <input type="text" placeholder="Funçao">
                            </section>
                        </div>
                        <div>
                            <section class="email">
                                <input type="text" placeholder="email">
                            </section>
                        </div>
                        <div>
                            <section class="telefone">
                                <input type="text" placeholder="telefone">
                            </section>
                        </div>
                        <div>
                            <section class="categoria">
                                <input type="text" placeholder="categoria">
                            </section>
                        </div>
                        <div>
                            <section class="enviar">
                                <button class="enviarb">Cadastrar</button>
                            </section>
                        </div>
                    </div>
                </div>
        </div>
    </main>
</body>
<style>
    form {
        position: absolute;
        top: -100px;
        background-color: #824700;
        width: 93.5%;
        padding: 115px 0.3em 10px 7em;
        height: auto;

    }

    .texto {
        width: 369px;
        height: 23px;
        left: 980px;
        top: 80px;

        font-family: 'Poppins';
        font-style: normal;
        font-weight: 700;
        font-size: 20px;
        line-height: 30px;
        text-align: center;
        color: #FFFFFF;
        display: flex;
        float: right;

    }

    .logo {
        width: 198px;
        height: 57px;
        left: 135px;
        top: 36px;
    }

    .campo {
        width: 15%;
        float: left;
        color: #dc7f0d;
    }

    .campo input {
        margin: 5px 1%;
        padding: 5px 1%;
        width: 80%;
    }

    .campo select {
        margin: 5px 1%;
        padding: 5px 1%;
        width: 50%;
    }

    input[type="submit"] {
        text-align: center;
        text-transform: lowercase;
        font-weight: lighter;
        border: none;
        height: 40px;
        border-radius: 5px;
        margin-top: 30px;
        color: #FFFF;
        background: #FFAB40;
        cursor: pointer;
    }

    input[type="submit"]:hover {
        background-color: #c78b2b;
        transition: .5s;
    }

    .cadastro {
        color: #FFAB40;
    }

    .cadastro {
        position: absolute;
        top: 282px;
        width: 445px;
        left: 147px;
        font-family: Arial, Helvetica, sans-serif;
        font-size: 20px;

    }

    input::placeholder {
        color: white
    }

    .nomep {
        position: absolute;
        top: 40%;
        left: 147px;
        padding: 15px;
        outline: none;
        border-radius: 15px;
        outline: none;
        background-color: #CC7200;
    }

    .nomep>input {
        background-color: #CC7200;
        outline: none;
        border: none;
        color: white;
    }

    .senha {
        position: absolute;
        top: 40%;
        left: 474px;
        padding: 15px;
        outline: none;
        border-radius: 15px;
        outline: none;
        background-color: #CC7200;
    }

    .senha>input {
        background-color: #CC7200;
        outline: none;
        border: none;
        color: white;
    }

    .funçao {
        position: absolute;
        top: 40%;
        left: 820px;
        padding: 15px;
        border: none;
        outline: none;
        font-size: 15px;
        border-radius: 15px;
        outline: none;
        background-color: #CC7200;
    }

    .funçao>input {
        background-color: #CC7200;
        outline: none;
        border: none;
        color: white;
    }

    .email {
        position: absolute;
        top: 40%;
        left: 1150px;
        padding: 15px;
        border: none;
        outline: none;
        font-size: 15px;
        border-radius: 15px;
        outline: none;
        background-color: #CC7200;
    }

    .email>input {
        background-color: #CC7200;
        outline: none;
        border: none;
        color: white;
    }

    .telefone {
        position: absolute;
        top: 40%;
        left: 1500px;
        padding: 15px;
        border: none;
        outline: none;
        font-size: 15px;
        border-radius: 15px;
        outline: none;
        background-color: #CC7200;
    }

    .telefone>input {
        background-color: #CC7200;
        outline: none;
        border: none;
        color: white;
    }

    .categoria {
        position: absolute;
        top: 50%;
        left: 147px;
        padding: 15px;
        outline: none;
        border-radius: 15px;
        outline: none;
        background-color: #CC7200;
    }

    .categoria>input {
        background-color: #CC7200;
        outline: none;
        border: none;
        color: white;
    }

    .enviarb {
        position: absolute;
        left: 847px;
        top: 50%;
        background-color: #CC7200;
        color: white;
        border: none;
        border-radius: 10px;
        cursor: pointer;
        padding: 50px;
    }

    button:hover {
        background-color: #c78b2b;
    }
</style>