<body class="container" style="background-color: #E5E5E5;">
    <div>
        <h1 class="lista_compras" style="color: #FFAB40; margin-top: 200px;">Lista de Compras</h1>
    </div>
    <!--Início Cards de Compras-->
    <div class="row card_compras">
        <div class="col-4">
            <div class="card text-white" style="background-color: #824700;">
                <div class="card-body">
                  <h5 class="card-title" style="text-align: center; margin-bottom: 25px;">Compra 2917</h5>
                  <p class="card-text" style="margin-left: 50px;"> <i class="fa-solid fa-bread-slice" style="color: #FFAB40;" ></i> Pão de Sal</p>
                  <p style="margin-left: 70px;"> Quantidade: 03</p>
                  <p style="margin-left: 70px;"> Valor Total: 10,90</p>
                  <p style="margin-left: 50px;"> <i class="fa-solid fa-bread-slice " style="color: #FFAB40;"></i> Pão Doce</p>
                  <p style="margin-left: 70px;"> Quantidade: 01</p>
                  <p style="margin-left: 70px;"> Valor Total: 5,30</p>
                  <p style="margin-left: 50px;"><i class="fa-regular fa-user" style="color: #FFAB40;"></i> Cliente</p>
                  <p style="margin-left: 70px;"> Nome: Pedro</p>
                  <p style="margin-left: 70px;"> Email: Pedro@teste.com</p>
                </div>
              </div>
        </div>
        <div class="col-4">
            <div class="card text-white" style="background-color: #824700;">
                <div class="card-body">
                  <h5 class="card-title" style="text-align: center; margin-bottom: 25px;">Compra 2917</h5>
                  <p class="card-text" style="margin-left: 50px;"> <i class="fa-solid fa-bread-slice" style="color: #FFAB40;"></i> Pão de Sal</p>
                  <p style="margin-left: 70px;"> Quantidade: 03</p>
                  <p style="margin-left: 70px;"> Valor Total: 10,90</p>
                  <p style="margin-left: 50px;"> <i class="fa-solid fa-bread-slice" style="color: #FFAB40;"></i> Pão Doce</p>
                  <p style="margin-left: 70px;"> Quantidade: 01</p>
                  <p style="margin-left: 70px;"> Valor Total: 5,30</p>
                  <p style="margin-left: 50px;"><i class="fa-regular fa-user" style="color: #FFAB40;"></i> Cliente</p>
                  <p style="margin-left: 70px;"> Nome: Pedro</p>
                  <p style="margin-left: 70px;"> Email: Pedro@teste.com</p>
                </div>
              </div>
        </div>
        <div class="col-4">
            <div class="card text-white" style="background-color: #824700;">
                <div class="card-body">
                  <h5 class="card-title" style="text-align: center; margin-bottom: 25px;">Compra 2917</h5>
                  <p class="card-text" style="margin-left: 50px;"><i class="fa-solid fa-bread-slice" style="color: #FFAB40;"></i> Pão de Sal</p>
                  <p style="margin-left: 70px;"> Quantidade: 03</p>
                  <p style="margin-left: 70px;"> Valor Total: 10,90</p>
                  <p style="margin-left: 50px;"><i class="fa-solid fa-bread-slice" style="color: #FFAB40;"></i> Pão Doce</p>
                  <p style="margin-left: 70px;"> Quantidade: 01</p>
                  <p style="margin-left: 70px;"> Valor Total: 5,30</p>
                  <p style="margin-left: 50px;"><i class="fa-regular fa-user" style="color: #FFAB40;"></i> Cliente</p>
                  <p style="margin-left: 70px;"> Nome: Pedro</p>
                  <p style="margin-left: 70px;"> Email: Pedro@teste.com</p>
                </div>
              </div>
        </div>
    </div>
    <!--Fim Cards de Compras-->
    <!--Bootstrap-->
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.10.2/dist/umd/popper.min.js" integrity="sha384-7+zCNj/IqJ95wo16oMtfsKbZ9ccEh31eOz1HGyDuCQ6wgnyJNSYdrPa03rtR1zdB" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.min.js" integrity="sha384-QJHtvGhmr9XOIpI6YVutG+2QOK9T+ZnN4kzFN1RtK3zEFEIsxhlmWl5/YESvpZ13" crossorigin="anonymous"></script>
</body>