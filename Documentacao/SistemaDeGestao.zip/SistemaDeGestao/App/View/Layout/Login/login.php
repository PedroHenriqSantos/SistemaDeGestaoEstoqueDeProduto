<body>
    <div class="login">
        <img class="logo" src="fotos/Logo.png" alt="imagem">
        <br><br>
        <input class="email" tipe="text" placeholder="Email">
        <br><br>
        <input class="senha" type="password" placeholder="senha">
        <br><br>
        <button class="enviar">Enviar</button>
    </div>
</body>


<style>
    body {
        font-family: Arial, Helvetica, sans-serif;
        background-color: #824700;
    }

    .login {
        background-color: rgba(0, 0, 0, 0);
    }

    .login {
        position: absolute;
    }

    .login {
        top: 40%;
    }

    .login {
        left: 49%;
    }

    .login {
        transform: translate(-50%, -50%);
    }

    .Coffe {
        color: #FFAB40;
    }

    .login {
        padding: 80px;
    }

    .senha {
        background-color: #FFAB40;
    }

    .email {
        background-color: #FFAB40;
    }

    .enviar {
        background-color: #DD6B20;
    }

    .enviar {
        border: none;
    }

    .enviar {
        padding: 80%;
    }

    .email {
        border-radius: 10px;
    }

    .senha {
        border-radius: 10px;
    }


    input {
        padding: 15px;
        outline: none;
    }

    .enviar {
        padding: 15px;
        width: 100%;
        color: white;
        border-radius: 10px;
        cursor: pointer;
    }

    button:hover {
        background-color: #FFAB40;
    }
</style>