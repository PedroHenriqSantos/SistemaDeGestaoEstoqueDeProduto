<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <script src="https://kit.fontawesome.com/1d743cb0e8.js" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="<?= 'http://' . APP_HOST. '/App/View/Styles/styles.css' ?>">
    <title><?= TITLE ?></title>
</head>
    <!--Header-->
    <header> 
        
        <form id="Sistema">
        
            <div class="logo">
                <img src="<?= 'http://' . APP_HOST. '/App/View/Images/Logo.png' ?>" alt="logo">
            </div> 
            <div class="texto">
                <h3>Olá Pedro, Bem vindo!</h3>
            </div>
            <div class="campo">
              <input type=submit value="Cadastrar Produto">
            </div>
            
            <div class="campo">
                <input type="submit" value="cadastrar Categoria"/>
            </div> 
  
        </form>
           
  </header>