<body>

    <main>
        <div class="cadastro">
            <section>

                <H1>Cadastro de Categoria</H1>

            </section>
            <section class="area dos cadastro">
        </div>
        <div>
            <section class="nomep">
                <input type="text" placeholder=Nome da categoria">
            </section>
        </div>
        <div>
            <section class="enviar">
                <button class="enviarb">Cadastrar</button>
            </section>
        </div>
    </main>
</body>
<style>
    form {
        position: absolute;
        top: -100px;
        background-color: #824700;
        width: 93.5%;
        padding: 115px 0.3em 10px 7em;
        height: auto;

    }

    .texto {
        width: 369px;
        height: 23px;
        left: 980px;
        top: 80px;

        font-family: 'Poppins';
        font-style: normal;
        font-weight: 700;
        font-size: 20px;
        line-height: 30px;
        text-align: center;
        color: #FFFFFF;
        display: flex;
        float: right;

    }

    .logo {
        width: 198px;
        height: 57px;
        left: 135px;
        top: 36px;
    }

    .campo {
        width: 15%;
        float: left;
        color: #dc7f0d;
    }

    .campo input {
        margin: 5px 1%;
        padding: 5px 1%;
        width: 80%;
    }

    .campo select {
        margin: 5px 1%;
        padding: 5px 1%;
        width: 50%;
    }

    input[type="submit"] {
        text-align: center;
        text-transform: lowercase;
        font-weight: lighter;
        border: none;
        height: 40px;
        border-radius: 5px;
        margin-top: 30px;
        color: #FFFF;
        background: #FFAB40;
        cursor: pointer;
    }

    input[type="submit"]:hover {
        background-color: #c78b2b;
        transition: .5s;
    }

    .cadastro {
        color: #FFAB40;
    }

    .cadastro {
        position: absolute;
        top: 282px;
        width: 445px;
        left: 147px;
        font-family: Arial, Helvetica, sans-serif;
        font-size: 20px;

    }

    input::placeholder {
        color: white
    }

    .nomep {
        position: absolute;
        top: 40%;
        left: 147px;
        padding: 15px;
        outline: none;
        border-radius: 15px;
        outline: none;
        background-color: #CC7200;
    }

    .nomep>input {
        background-color: #CC7200;
        outline: none;
        border: none;
        color: white;
    }

    .enviarb {
        position: absolute;
        left: 500px;
        top: 40%;
        background-color: #CC7200;
        color: white;
        border: none;
        border-radius: 15px;
        cursor: pointer;
        padding: 15px;
    }

    button:hover {
        background-color: #c78b2b;
    }
</style>